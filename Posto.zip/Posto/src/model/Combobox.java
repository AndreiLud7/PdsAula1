package model;

public enum Combobox{
	diesel,
	comum,
	aditivada,
	etanol
}
